# Test package

A simple package used for local testing. Use `cargo-deb` to package as a debian package.
